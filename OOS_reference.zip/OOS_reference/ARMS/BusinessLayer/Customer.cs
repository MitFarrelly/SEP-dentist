﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PersistantLayer;

namespace BusinessLayer
{
    public class Customer
    {
        private int _CustomerID;

        public int CustomerID
        {
            get { return _CustomerID; }
            set { _CustomerID = value; }
        }
        public System.Data.DataTable GetAllCustomers() {
            return new PersistantLayer.DataBaseHandler().GetALLCustomers(); 
        }
    }
}
