﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PersistantLayer;
namespace BusinessLayer
{
    public class Job
    {
        private String jobID;
        private String bookingID;
        private int workTypeID;
        private String staffID;
        private bool isAssigned;
        private DateTime dateTime;

        public Job(String ID, String BookingID, int WorkTypeID, String StaffID, bool assigned, DateTime Date_Time)
        {
            jobID = ID;
            bookingID = BookingID;
            workTypeID = WorkTypeID;
            staffID = StaffID;
            isAssigned = assigned;
            dateTime = Date_Time;
        }

        public string GetID()
        {
            return jobID;
        }

        public void Assign(String staffAssigned)
        {
            staffID = staffAssigned;
            isAssigned = true;
        }

        public bool isAllocated()
        {
            return isAssigned;
        }

        public int getNeededTime()
        {
            DataBaseHandler database = new DataBaseHandler();
            int time;
            database.getWorkType(workTypeID, out time);
            return time;
        }

        public string GetStaffID()
        {
            return staffID;
        }
    }
}
