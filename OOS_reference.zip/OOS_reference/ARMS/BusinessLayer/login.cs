﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PersistantLayer;

namespace BusinessLayer
{
   
        public class login
        {
            /*
             * Method to perform login
             */
            public bool Login(string Staff_ID, string password)
            {
                bool isVerified = false;

                DataBaseHandler newUser = new DataBaseHandler();

                if (Staff_ID != "" && Staff_ID != null)
                    if (password != "" && password != null)
                        isVerified = newUser.login(Staff_ID, password);

                return isVerified;
            }
        }
    
}
