﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PersistantLayer;

namespace BusinessLayer
{
    class CreatePayment
    {
        public string createNewPayment(string Payment_ID, string Customer_ID, string CreditCard_NO, string NameOnCard, string ExpireDate, string Status)
        {
            if (Payment_ID == "" || Customer_ID == "" || CreditCard_NO == "" || NameOnCard == "" || ExpireDate == "" || Status == "")
            {
                throw new Exception();
            }

            DataBaseHandler NewPayment = new DataBaseHandler();
            NewPayment.createPayment(Payment_ID, Customer_ID, CreditCard_NO, NameOnCard, ExpireDate, Status);
            return "Success";

        }
    }
}
