﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PersistantLayer;

namespace BusinessLayer
{
    public class SearchCustomer
    {
        public string[] searchCustomer(string Customer_ID)
        {
            if (Customer_ID == "")
            {
                throw new Exception();
            }
            DataBaseHandler NewSearch = new DataBaseHandler();
            string[] result = NewSearch.searchrCustomer(Customer_ID);
            return result;
        }
    }
}
