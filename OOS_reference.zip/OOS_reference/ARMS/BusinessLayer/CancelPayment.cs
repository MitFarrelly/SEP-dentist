﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PersistantLayer;

namespace BusinessLayer
{
    public class CancelPayment
    {
        public string CancelPay(string Payment_ID)
        {
            SearchPayment s=new SearchPayment();
            if (Payment_ID == "")
            {
                throw new Exception();
            }
            DataBaseHandler DelPayment = new DataBaseHandler();

            if (s.searchPayment(Payment_ID)[0] == "Success")
            {
                DelPayment.deletePayment(Payment_ID);
                return "Success";
            }
            else
                return "Failure";
           
        }
    }
}
