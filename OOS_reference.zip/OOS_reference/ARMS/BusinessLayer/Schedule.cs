﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PersistantLayer;
using System.Data;

namespace BusinessLayer
{
    public class Schedule
    {
        private String scheduleID;
        private List<String> Jobs;
        private DateTime Date;

        public Schedule(DateTime date)
        {
            Date = date;
            Jobs = new List<string>();
        }

        public bool CaculateAvaliableRoom(int time)
        {
            DataBaseHandler database = new DataBaseHandler();
            int TotalTime = 0;
            foreach (String job in Jobs)
            {
                String BookingID , StaffID;
                int WorkTypeID;
                bool assigned;
                DateTime Date_Time;
                DataBaseHandler.Status stat = database.getJob(job, out BookingID, out WorkTypeID, out StaffID, out assigned, out Date_Time);
                if (stat != DataBaseHandler.Status.correct)
                    return false;
                Job tempJob = new Job(job, BookingID, WorkTypeID, StaffID, assigned, Date_Time);
                TotalTime += tempJob.getNeededTime();
            }

            if ((time + TotalTime) < 8)
                return true;
            return false;
        }

        public List<String> SortByStaff(String StaffID)
        {
            DataBaseHandler database = new DataBaseHandler();
            List<String> tempJobs = new List<String>();

            DataBaseHandler.Status stat = database.getStaff(StaffID);
            if (stat != DataBaseHandler.Status.correct)
                return tempJobs;
            foreach (string job in Jobs)
            {
                String BookingID, staffID;
                int WorkTypeID;
                bool assigned;
                DateTime Date_Time;
                stat = database.getJob(job, out BookingID, out WorkTypeID, out staffID, out assigned, out Date_Time);
                if (stat == DataBaseHandler.Status.correct)
                {
                    if (StaffID == staffID)
                        tempJobs.Add(job);
                }
            }
            return tempJobs;
        }

        public void addJob(String job)
        {
            Jobs.Add(job);
        }

        public DateTime GetDate()
        {
            return Date;
        }
    }
}
