﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace BusinessLayer
{
    class Quotation
    {
        private int _QuotationID;
        private Booking _objBooking;
        private DateTime _Date;
        private decimal _Total;

        public int QuotationID
        {
            get { return _QuotationID; }
            set { _QuotationID = value; }
        }
        public Booking ObjBooking
        {
            get { return _objBooking; }
            set { _objBooking = value; }
        }
        public DateTime Date
        {
            get { return _Date; }
            set { _Date = value; }
        }
        public decimal Total
        {
            get { return _Total; }
            set { _Total = value; }
        }

        public FileStream GenerateQuotation(Booking objBooking) {
            return null;
        }

    }

}
