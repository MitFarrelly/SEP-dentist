﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PersistantLayer;

namespace BusinessLayer
{
    public class CreateCustomer
    {

        public string createNewCustomer(string Customer_ID, string FirstName, string LastName, string Title, string ContactNum, string Email, string Street, string Suburb, string State, string PostCode, string PaymentMethod, string Member)
        {
            if (Customer_ID == "" || FirstName == "" || LastName == "" || Title == "" || ContactNum == "" || Email == "" || Street == "" || Suburb == "" || State == "" || PostCode == "" || PaymentMethod == "" || Member == "")
            {
                throw new Exception();
            }
            
            DataBaseHandler NewCustomer = new DataBaseHandler();
            //if (NewCustomer.searchrCustomer(Customer_ID)[0] != "Success")
            //{
                NewCustomer.createCustomer(Customer_ID, FirstName, LastName, Title, ContactNum, Email, Street, Suburb, State, PostCode, PaymentMethod, Member);
                return "Success";
            //}
            //else
              //  return "Failure";

        }
    }
}
