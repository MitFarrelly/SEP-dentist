﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PersistantLayer;

namespace BusinessLayer
{
    public class SearchPayment
    {
        public string[] searchPayment(string Payment_ID)
        {
            if (Payment_ID == "")
            {
                throw new Exception();
            }
            DataBaseHandler NewSearch = new DataBaseHandler();
            string[] result = NewSearch.searchPayment(Payment_ID);
            return result;
        }

        public string[] searchPayment2(string Customer_ID)
        {
            if (Customer_ID == "")
            {
                throw new Exception();
            }
            DataBaseHandler NewSearch = new DataBaseHandler();
            string[] result = NewSearch.searchPaymentThruCustomer(Customer_ID);
            return result;
        }
    }
}
