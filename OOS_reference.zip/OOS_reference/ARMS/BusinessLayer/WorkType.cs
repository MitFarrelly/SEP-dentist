﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessLayer
{
    public class WorkType
    {

        private DateTime HoursNeeded;
        private int _WorkTypeID;
        private string _Description;
        private string[] _EquipmentNeeded;
        private double _EstimatedCost;
        private double _MemberCost;

        public double MemberCost
        {
            get { return _MemberCost; }
            set { _MemberCost = value; }
        }
        private double _NonMemberCost;

        public double NonMemberCost
        {
            get { return _NonMemberCost; }
            set { _NonMemberCost = value; }
        }
        


        public DateTime GetHours()
        {
            return HoursNeeded;
        }

        public int WorkTypeID
        {
            get { return _WorkTypeID; }
            set { _WorkTypeID = value; }
        }
        public string Description
        {
            get { return _Description; }
            set { _Description = value; }
        }
        /*public string EstimatedTime
        {
            get { return _EstimatedTime; }
            set { _EstimatedTime = value; }
        }*/
        public string[] EquipmentNeeded
        {
            get { return _EquipmentNeeded; }
            set { _EquipmentNeeded = value; }
        }
        public double EstimatedCost
        {
            get { return _EstimatedCost; }
            set { _EstimatedCost = value; }
        }
        
    }
}
