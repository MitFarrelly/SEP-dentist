﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PersistantLayer;

namespace BusinessLayer
{
    public class Booking
    {
        private int _BookingNo;
        private Customer _objCustomer = new Customer();
        private string _RegNo;
        private DateTime _Date;
        private string _Description;
        private string _Status;
        private List<WorkType> _objWorkTypes = new List<WorkType>();

        public int GetTimeNeeded()
        {
            DataBaseHandler dataBase = new DataBaseHandler();
            int totalTime = 0;
            int time = 0;
            for (int i = 0; i < 3; i++)
            {
                if (_objWorkTypes != null)
                {
                    if (_objWorkTypes[i] != null)
                    {
                        dataBase.getWorkType(_objWorkTypes[i].WorkTypeID, out time);
                        totalTime += time;
                    }
                }
            }
            return totalTime;
        }

        public bool isValid()
        {
            //if (workTypeID[0] == "0" && workTypeID[1] == "0" && workTypeID[2] == "0")
            //    return false;
            if (_Date < new DateTime(2013, 4, 19))
                return false;
            if (GetTimeNeeded() >= 8)
                return false;
            return true;
        }

        public int BookingNo
        {
            get { return _BookingNo; }
            set { _BookingNo = value; }
        }
        public Customer ObjCustomer
        {
            get { return _objCustomer; }
            set { _objCustomer = value; }
        }
        public string RegNo
        {
            get { return _RegNo; }
            set { _RegNo = value; }
        }
        public DateTime Date
        {
            get { return _Date; }
            set { _Date = value; }
        }
        public string Description
        {
            get { return _Description; }
            set { _Description = value; }
        }
        public string Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        public List<WorkType> ObjWorkTypes
        {
            get { return _objWorkTypes; }
            set { _objWorkTypes = value; }
        }

        public int[] WorkTypeIDS()
        {
            int[] list = new int[3];
            int i =0;
            foreach(WorkType work in _objWorkTypes)
            {
                list[i] = work.WorkTypeID;
                i++;
            }
            return list;
        }

        public Booking Create(int CustomerID, string RegNo, List<WorkType> objWorkTypes, string Description, DateTime Date)
        {
            Booking objBooking = new Booking();
            objBooking.ObjCustomer.CustomerID = CustomerID;
            objBooking.RegNo = RegNo;
            objBooking.ObjWorkTypes = objWorkTypes;
            objBooking.Description = Description;
            objBooking.Date = Date;
            objBooking.Status = "New";
            return objBooking;
        }
    }
}
