﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PersistantLayer;

namespace BusinessLayer
{
    public class CancelCustomer
    {
        public string CancelCust(string Customer_ID)
        {
            SearchCustomer s = new SearchCustomer();
            if (Customer_ID == "")
            {
                throw new Exception();
            }
            DataBaseHandler DelCustomer = new DataBaseHandler();
           
            if (s.searchCustomer(Customer_ID)[0] == "Success")
            {
                DelCustomer.deleteCustomer(Customer_ID);

                return "Success";
            }
            else
                return "Failure";
        }

    }
}
