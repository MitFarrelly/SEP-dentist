﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BusinessLayer;
using PersistantLayer;

namespace ControllerClass
{
    public class Scheduler
    {
        private DateTime TodaysDate;
        private DataBaseHandler dataBase;

        public Scheduler(DateTime date)
        {
            TodaysDate = date;
            dataBase = new DataBaseHandler();
        }

        public bool allocateJob(String jobID, String staffID)
        {
            String FirstName = "";

            string[] words = staffID.Split(' ');
            FirstName = words[0];

            string ID = dataBase.getStaffName(FirstName);

            String JobID = "";

            words = jobID.Split(' ');
            JobID = words[0];

            String BookingID, StaffID;
            int WorkTypeID;
            bool assigned;
            DateTime Date_Time;
            DataBaseHandler.Status stat = dataBase.getJob(JobID, out BookingID, out WorkTypeID, out StaffID, out assigned, out Date_Time);
            if (stat != DataBaseHandler.Status.correct)
                return false;

            assigned = true;
            dataBase.updateJob(Convert.ToInt32(JobID), Convert.ToInt32(ID), assigned);
            return true;
        }

        public bool CheckBooking(DateTime date, Booking booking)
        {
            if (date < new DateTime(2013, 4, 19))
                return false;
            Schedule schedule = FindSchedule(date);
            //if (schedule == null)
                
            return schedule.CaculateAvaliableRoom(booking.GetTimeNeeded());
        }

        public bool CheckBooking(DateTime date, List<String> Descriptions)
        {
            if (date < new DateTime(2013, 4, 19))
                return false;
            Schedule schedule = FindSchedule(date);
            //if (schedule == null)

            List<WorkType> objWorkTypes = new List<WorkType>();
            foreach (String work in Descriptions)
            {
                WorkType tempworkType = new WorkType();
                int ID;
                dataBase.getWorkTypeByDescription(work, out ID);
                tempworkType.WorkTypeID = ID;
                objWorkTypes.Add(tempworkType);
            }
            while (objWorkTypes.Count < 3)
            {
                WorkType tempworkType = new WorkType();
                tempworkType.WorkTypeID = 0;
                objWorkTypes.Add(tempworkType);
            }

            Booking temp = new Booking();
            temp = temp.Create(-1, "", objWorkTypes, "", date);

            return schedule.CaculateAvaliableRoom(temp.GetTimeNeeded());
        }

        public Schedule FindSchedule(DateTime date)
        {
            List<string> jobs = dataBase.getSchedule(date);
            Schedule schedule = new Schedule(date);
            foreach(string job in jobs)
            {
                schedule.addJob(job);
            }
            return schedule;
        }

        public DateTime FindEarliestBooking(List<String> Descriptions)
        {
            List<WorkType> objWorkTypes = new List<WorkType>();
            foreach (String work in Descriptions)
            {
                WorkType tempworkType = new WorkType();
                int ID;
                dataBase.getWorkTypeByDescription(work, out ID);
                tempworkType.WorkTypeID = ID;
                objWorkTypes.Add(tempworkType);
            }
            while (objWorkTypes.Count < 3)
            {
                WorkType tempworkType = new WorkType();
                tempworkType.WorkTypeID = 0;
                objWorkTypes.Add(tempworkType);
            }

            Booking booking = new Booking();
            booking = booking.Create(-1, "", objWorkTypes, "", TodaysDate);

            if (!booking.isValid())
                return new DateTime(1, 1, 1);
            DateTime tempDate = TodaysDate;
            bool found = false;
            while(found == false)
            {
                if (CheckBooking(tempDate, booking) == false)
                    tempDate = tempDate.AddDays(1);
                else
                    found = true;
                if (tempDate > new DateTime(2013, 5, 1))
                    return tempDate;
            }
            return tempDate;
        }

        public DateTime FindEarliestBooking(Booking booking)
        {
            if (!booking.isValid())
                return new DateTime(1, 1, 1);
            DateTime tempDate = TodaysDate;
            bool found = false;
            while (found == false)
            {
                if (CheckBooking(tempDate, booking) == false)
                    tempDate = tempDate.AddDays(1);
                else
                    found = true;
                if (tempDate > new DateTime(2013, 5, 1))
                    return tempDate;
            }
            return tempDate;
        }

        public List<String> lookUpSchedule(string StaffID, DateTime date)
        {
            if (date < new DateTime(2013, 4, 19))
                return new List<String>();
            Schedule schedule = FindSchedule(date);
            return schedule.SortByStaff(StaffID);
        }

        public List<String> lookUpScheduleFromName(string Name, DateTime date)
        {
            String FirstName = "";

            string[] words = Name.Split(' ');
            FirstName = words[0];

            string ID = dataBase.getStaffName(FirstName);

                if (date < new DateTime(2013, 4, 19))
                    return new List<String>();
            Schedule schedule = FindSchedule(date);
            List<String> workIDS = schedule.SortByStaff(ID);

            List<String> description = new List<string>();
            foreach (String work in workIDS)
            {
                System.Data.DataTable dtWorkTypes = dataBase.GetWorkTypeByID(Convert.ToInt32(work));
                if (dtWorkTypes != null)
                {
                    foreach (System.Data.DataRow dr in dtWorkTypes.Rows)
                    {
                        WorkType objWorkType = new WorkType();
                        description.Add(dr["Description"].ToString());
                    }
                }
            }
            return description;
        }

        public List<String> getWorktypes()
        {
            List<String> description = new List<String>();
            System.Data.DataTable dtWorkTypes = dataBase.GetAllWorkTypes();

            foreach (System.Data.DataRow dr in dtWorkTypes.Rows)
            {
                WorkType objWorkType= new WorkType();
                description.Add(dr["Description"].ToString());
            }

            return description;
        }

        public List<String> getStaffNames()
        {
            List<String> Name = new List<String>();
            System.Data.DataTable dtStaff = dataBase.getAllStaff();

            foreach (System.Data.DataRow dr in dtStaff.Rows)
            {
                string name;
                name = dr["FirstName"].ToString() + " " + dr["LastName"].ToString();
                Name.Add(name);
            }
            return Name;
        }


        public List<String> SearchUnallocatedJobs()
        {
            List<String> job = new List<String>();

            System.Data.DataTable dtJob = dataBase.getAllUnalocatedJob();
            foreach (System.Data.DataRow dr in dtJob.Rows)
            {
                string name;

                name = dr["JobID"].ToString() + " ";
                System.Data.DataTable dtWork = dataBase.GetWorkTypeByID(Convert.ToInt32(dr["WorkTypeID"].ToString()));
                foreach (System.Data.DataRow drWork in dtWork.Rows)
                {
                    name += drWork["Description"] + " ";
                }
                name += ((DateTime)dr["JobDate"]).Date.ToString();
                job.Add(name);
            }
            return job;
        }
    }
}
