﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BusinessLayer;
using PersistantLayer;

namespace ControllerClass
{
    public  class BookingController
    {
        private static Booking _objCurrentBooking;

        private DataBaseHandler objDBController = new DataBaseHandler();
        //private SchedulerController objSchedulerController;
        private WorkType objWorkType;


        public static Booking ObjCurrentBooking
        {
            get { return _objCurrentBooking; }
            set { _objCurrentBooking = value; }
        }


        public Booking RequestBooking(int CustomerID, string RegNo, List<WorkType> objWorkTypes, DateTime Date, string Description)
        {
            BusinessLayer.Booking objBooking = new Booking();
            return objBooking.Create(CustomerID, RegNo, objWorkTypes, Description, Date);
        }
        public void SetCurrentBooking(Booking objBooking){
            ObjCurrentBooking = objBooking;
        }
        public DateTime SelectTimeSlot(DateTime dateTime){
            ObjCurrentBooking.Date = dateTime;
            return DateTime.MinValue;
        }
        public int ConfirmBooking(){
            int BookingNo = objDBController.SaveBooking(ObjCurrentBooking.Date, ObjCurrentBooking.Status, ObjCurrentBooking.ObjCustomer.CustomerID, ObjCurrentBooking.RegNo, ObjCurrentBooking.Description, ObjCurrentBooking.WorkTypeIDS());
            ObjCurrentBooking = null;
            ObjCurrentBooking = new Booking();
            return BookingNo;
        }
        public List<WorkType> GetAllWorkTypes(){
            System.Data.DataTable dtWorkTypes = objDBController.GetAllWorkTypes();
            List<WorkType> lstWorkTypes = new List<WorkType>();
            foreach (System.Data.DataRow dr in dtWorkTypes.Rows)
            {
                WorkType objWorkType= new WorkType();
                objWorkType.Description = dr["Description"].ToString();
                objWorkType.EquipmentNeeded = dr["EquipmentNeeded"].ToString().Split(',');
                objWorkType.MemberCost = double.Parse(dr["MemberCost"].ToString());
                objWorkType.NonMemberCost = double.Parse(dr["NonMemberCost"].ToString());
                //objWorkType.EstimatedTime = dr["EstimatedTime"].ToString();
                objWorkType.WorkTypeID = int.Parse(dr["WorkTypeID"].ToString());
                lstWorkTypes.Add(objWorkType);
            }
            return lstWorkTypes;
        }

        public WorkType GetWorkTypeByID(int WorkTypeID)
        {
            System.Data.DataTable dtWorkTypes = objDBController.GetWorkTypeByID(WorkTypeID);
            List<WorkType> lstWorkTypes = new List<WorkType>();
            WorkType objWorkType = new WorkType();
            foreach (System.Data.DataRow dr in dtWorkTypes.Rows)
            {
                objWorkType.Description = dr["Description"].ToString();
                objWorkType.EquipmentNeeded = dr["EquipmentNeeded"].ToString().Split(',');
                objWorkType.MemberCost = double.Parse(dr["MemberCost"].ToString());
                objWorkType.NonMemberCost = double.Parse(dr["NonMemberCost"].ToString());
                objWorkType.WorkTypeID = int.Parse(dr["WorkTypeID"].ToString());
                lstWorkTypes.Add(objWorkType);
            }
            return objWorkType;
        }

        public int CancelBooking(int BookingNo){
            try
            {
                return objDBController.DeleteBooking(BookingNo);
            }
            catch (System.ArgumentException e)
            {
                return 0;
            }
            catch (System.FormatException e)
            {
                return 0;
            }
            finally
            {


            }
            
        }

        public List<Booking> ShowCurrentBookings(int CustomerID)
        {
            System.Data.DataTable dtBookings = objDBController.FetchBookings(CustomerID);
            List<Booking> lstBooking = new List<Booking>();
            foreach (System.Data.DataRow dr in dtBookings.Rows) {
                Booking objNewBooking = new Booking();
                objNewBooking.BookingNo = int.Parse(dr["BookingID"].ToString());
                objNewBooking.RegNo = dr["RegNo"].ToString();
                objNewBooking.Description = dr["Description"].ToString();
                objNewBooking.ObjCustomer = new Customer();
                objNewBooking.ObjCustomer.CustomerID = int.Parse(dr["CustomerID"].ToString());
                //objNewBooking.Date = DateTime.Parse(dr["ServiceDate"].ToString() + " " + dr["ServiceTime"].ToString());
                objNewBooking.Date = DateTime.Parse(DateTime.Parse(dr["ServiceDate"].ToString()).ToShortDateString() + " " + DateTime.Parse(dr["ServiceTime"].ToString()).ToShortTimeString());
                objNewBooking.ObjWorkTypes = SearchBooking(objNewBooking.BookingNo).ObjWorkTypes;
                objNewBooking.Status = dr["status"].ToString();
                lstBooking.Add(objNewBooking);
            }
            return lstBooking;
        }

        public Booking SearchBooking(int BookingNo)
        {
            try
            {
                System.Data.DataSet dsBookings = objDBController.FetchBookingDetails(BookingNo);
                Booking objNewBooking = new Booking();
                if (dsBookings != null)
                {
                    if (dsBookings.Tables.Count != 0)
                    {
                        foreach (System.Data.DataRow dr in dsBookings.Tables[0].Rows)
                        {
                            objNewBooking.BookingNo = int.Parse(dr["BookingID"].ToString());
                            objNewBooking.RegNo = dr["RegNo"].ToString();
                            objNewBooking.Description = dr["Description"].ToString();
                            objNewBooking.ObjCustomer = new Customer();
                            objNewBooking.ObjCustomer.CustomerID = int.Parse(dr["CustomerID"].ToString());
                            //objNewBooking.Date = DateTime.Parse(dr["ServiceDate"]. + " " + dr["ServiceTime"].ToString());
                            objNewBooking.Date = DateTime.Parse(DateTime.Parse(dr["ServiceDate"].ToString()).ToShortDateString() + " " + DateTime.Parse(dr["ServiceTime"].ToString()).ToShortTimeString());

                            objNewBooking.Status = dr["status"].ToString();



                            foreach (System.Data.DataRow drDetail in dsBookings.Tables[1].Rows)
                            {
                                WorkType objWorkType = new WorkType();
                                objWorkType.WorkTypeID = int.Parse(drDetail["WorkTypeID"].ToString());
                                objWorkType.Description = drDetail["Description"].ToString();
                                //objWorkType.EstimatedTime = drDetail["EstimatedTime"].ToString();
                                //objWorkType.EquipmentNeeded = drDetail["EquipmentNeeded"].ToString().Split(',');
                                objNewBooking.ObjWorkTypes.Add(objWorkType);
                                objWorkType = null;
                            }
                        }
                    }
                }

                return objNewBooking;
            }
            catch (System.FormatException e)
            {
                return null;
            }
            catch (System.ArgumentException e) {
                return null;
            }
            catch (System.Exception e) {
                return null;
            }
            
        }
    }
}
