﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayer;

namespace KangrooUniversity.Customer
{
    public partial class CancelCustomer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(this.TextBox1.Text))
            {
                BusinessLayer.CancelCustomer ObjCustomer = new BusinessLayer.CancelCustomer();
                Result.Text = ObjCustomer.CancelCust(this.TextBox1.Text);
            }       
        }
    }
}