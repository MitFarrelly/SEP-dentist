﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayer;

namespace KangrooUniversity
{
    public partial class _CreateCustomer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
             CreateCustomer c = new CreateCustomer();
             string isCreate = "";
             isCreate = c.createNewCustomer("1", FirstName.Text, LastName.Text, _Title.Text, ContNum.Text, Email.Text, Street.Text, Suburb.Text, State.Text, postCode.Text, Payment.Text, "true");
             //isCreate = c.createNewCustomer("1",  "yty", "rrr", "g", "2131321329132", "o@.com", "212", "221", "ap", "dp", "card", "true");
             
        }
    }
}