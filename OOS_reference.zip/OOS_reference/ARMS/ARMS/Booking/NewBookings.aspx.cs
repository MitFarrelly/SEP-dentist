﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayer;
using ControllerClass;

namespace KangrooUniversity
{
    public partial class NewBookings : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack == false) {
                List<WorkType> lstWorkTypeBooking = new List<WorkType>();
                lstWorkTypeBooking = new ControllerClass.BookingController().GetAllWorkTypes();

                ddlServiceType1.DataTextField = "Description";
                ddlServiceType1.DataValueField = "WorkTypeID";
                ddlServiceType1.DataSource = lstWorkTypeBooking;
                ddlServiceType1.DataBind();

                ddlServiceType2.DataTextField = "Description";
                ddlServiceType2.DataValueField = "WorkTypeID";
                ddlServiceType2.DataSource = lstWorkTypeBooking;
                ddlServiceType2.DataBind();

                ddlServiceType3.DataTextField = "Description";
                ddlServiceType3.DataValueField = "WorkTypeID";
                ddlServiceType3.DataSource = lstWorkTypeBooking;
                ddlServiceType3.DataBind();

                ddlCustomers.DataTextField = "FullName";
                ddlCustomers.DataValueField = "CustomerID";
                ddlCustomers.DataSource = new BusinessLayer.Customer().GetAllCustomers();
                ddlCustomers.DataBind();

                hdnTodaysDate.Value = DateTime.Now.ToString("dd/MM/yyyy");

                if (Request.QueryString["ID"] != null) {
                    if (!String.IsNullOrEmpty(Request.QueryString["ID"])) {
                        Booking objBooking = new BookingController().SearchBooking(int.Parse(Request.QueryString["ID"]));
                        ddlCustomers.SelectedValue = objBooking.ObjCustomer.CustomerID.ToString();
                        txtRegNo.Text = objBooking.RegNo;

                        DateTime start = DateTime.Parse(objBooking.Date.ToString("dd/MM/yyyy"));
                        DateTime end = DateTime.Parse(hdnTodaysDate.Value);

                        if (start < end)
                        {
                            txtBookingDate.Text = ""; 
                        }
                        else
                        {
                            txtBookingDate.Text = objBooking.Date.ToString("dd/MM/yyyy"); 
                        }



                        if (objBooking.ObjWorkTypes != null) {

                            if (objBooking.ObjWorkTypes.Count > 0) {
                                if (objBooking.ObjWorkTypes[0] != null)
                                {
                                    ddlServiceType1.SelectedValue = objBooking.ObjWorkTypes[0].WorkTypeID.ToString();
                                }
                            }
                            if (objBooking.ObjWorkTypes.Count > 1) {
                                if (objBooking.ObjWorkTypes[1] != null)
                                {
                                    ddlServiceType2.SelectedValue = objBooking.ObjWorkTypes[1].WorkTypeID.ToString();
                                }
                            }
                            if (objBooking.ObjWorkTypes.Count > 2) {
                                if (objBooking.ObjWorkTypes[2] != null)
                                {
                                    ddlServiceType3.SelectedValue = objBooking.ObjWorkTypes[2].WorkTypeID.ToString();
                                }
                            }
                            
                            
                        }


                        
                        ddlBookingTime.SelectedValue=objBooking.Date.ToString("hh:mm tt");
                        txtDesc.Text = objBooking.Description;

                        List<WorkType> objWorkTypes = new List<WorkType>();
                        if (ddlServiceType1.SelectedValue != "0")
                        {
                            WorkType objWorkType1 = new WorkType();
                            objWorkType1.WorkTypeID = int.Parse(ddlServiceType1.SelectedValue);
                            objWorkTypes.Add(objWorkType1);
                        }
                        if (ddlServiceType2.SelectedValue != "0")
                        {
                            WorkType objWorkType2 = new WorkType();
                            objWorkType2.WorkTypeID = int.Parse(ddlServiceType2.SelectedValue);
                            objWorkTypes.Add(objWorkType2);
                        }
                        if (ddlServiceType3.SelectedValue != "0")
                        {
                            WorkType objWorkType3 = new WorkType();
                            objWorkType3.WorkTypeID = int.Parse(ddlServiceType3.SelectedValue);
                            objWorkTypes.Add(objWorkType3);
                        }


                    }
                }

            }
        }
        protected void ValidateDate(object sender, ServerValidateEventArgs e)
        {
           
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            List<WorkType> objWorkTypes = new List<WorkType>();
            if (ddlServiceType1.SelectedValue != "0") 
            { 
                WorkType objWorkType1 = new WorkType();
                objWorkType1.WorkTypeID=int.Parse(ddlServiceType1.SelectedValue);
                objWorkTypes.Add(objWorkType1);
            }
            if (ddlServiceType2.SelectedValue != "0")
            {
                WorkType objWorkType2 = new WorkType();
                objWorkType2.WorkTypeID = int.Parse(ddlServiceType2.SelectedValue);
                objWorkTypes.Add(objWorkType2);
            }
            if (ddlServiceType3.SelectedValue != "0")
            {
                WorkType objWorkType3 = new WorkType();
                objWorkType3.WorkTypeID = int.Parse(ddlServiceType3.SelectedValue);
                objWorkTypes.Add(objWorkType3);
            }

            if (Request.QueryString["ID"] != null)
            {
                if (!String.IsNullOrEmpty(Request.QueryString["ID"])) {

                    new BookingController().CancelBooking(int.Parse(Request.QueryString["ID"]));
                }
            }


            Booking objBooking = new BookingController().RequestBooking(int.Parse(ddlCustomers.SelectedValue), txtRegNo.Text, objWorkTypes, DateTime.Parse(txtBookingDate.Text + " " + ddlBookingTime.SelectedItem.Text), txtDesc.Text);
            ControllerClass.BookingController.ObjCurrentBooking = objBooking;
            new BookingController().ConfirmBooking();
            Response.Redirect("ViewBookings.aspx");
        }
    }
}