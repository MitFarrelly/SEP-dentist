﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ControllerClass;

namespace KangrooUniversity.Schedule
{
    public partial class AssignJob : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (StaffList.Items.Count <= 0)
            {
                Scheduler controller = new Scheduler(DateTime.Today);
                List<String> descriptions = controller.getStaffNames();
                StaffList.Items.Add("------");
                foreach (String index in descriptions)
                {
                    StaffList.Items.Add(index);
                }
            }
            if (JobList.Items.Count <= 0)
            {
                Scheduler controller = new Scheduler(DateTime.Today);
                List<String> descriptions = controller.SearchUnallocatedJobs();
                JobList.Items.Add("------");
                foreach (String index in descriptions)
                {
                    JobList.Items.Add(index);
                }
            }
        }

        protected void Check_Click(object sender, EventArgs e)
        {
            if (StaffList.SelectedIndex != 0)
            {
                if (JobList.SelectedIndex != 0)
                {
                    Scheduler controller = new Scheduler(DateTime.Today);
                    bool results;
                    results = controller.allocateJob(JobList.SelectedItem.Text, StaffList.SelectedItem.Text);
                    txtResult.Text = results.ToString();
                }
            }
        }
    }
}