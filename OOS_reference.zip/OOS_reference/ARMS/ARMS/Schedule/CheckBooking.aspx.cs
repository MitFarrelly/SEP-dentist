﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ControllerClass;

namespace KangrooUniversity.Schedule
{
    public partial class CheckBooking : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (WorkType1.Items.Count <= 0)
            {
                Scheduler controller = new Scheduler(DateTime.Today);
                List<String> descriptions = controller.getWorktypes();
                WorkType1.Items.Add("------");
                WorkType2.Items.Add("------");
                WorkType3.Items.Add("------");
                foreach (String index in descriptions)
                {
                    WorkType1.Items.Add(index);
                    WorkType2.Items.Add(index);
                    WorkType3.Items.Add(index);
                }
                Calender.SelectedDate = DateTime.Today;
            }
        }

        protected void WorkType1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (WorkType1.SelectedIndex != 0)
                if (WorkType1.SelectedIndex == WorkType2.SelectedIndex || WorkType1.SelectedIndex == WorkType3.SelectedIndex)
                {
                    WorkType1.SelectedIndex = 0;
                }
        }

        protected void WorkType2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (WorkType2.SelectedIndex != 0)
                if (WorkType1.SelectedIndex == WorkType2.SelectedIndex || WorkType2.SelectedIndex == WorkType3.SelectedIndex)
                {
                    WorkType2.SelectedIndex = 0;
                }
        }

        protected void WorkType3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (WorkType3.SelectedIndex != 0)
                if (WorkType1.SelectedIndex == WorkType3.SelectedIndex || WorkType2.SelectedIndex == WorkType3.SelectedIndex)
                {
                    WorkType3.SelectedIndex = 0;
                }
        }

        protected void Check_Click(object sender, EventArgs e)
        {
            List<String> Descriptions = new List<string>();
            if (WorkType1.SelectedIndex != 0)
            {
                Descriptions.Add(WorkType1.SelectedItem.Text);
            }
            if (WorkType2.SelectedIndex != 0)
            {
                Descriptions.Add(WorkType2.SelectedItem.Text);
            }
            if (WorkType3.SelectedIndex != 0)
            {
                Descriptions.Add(WorkType3.SelectedItem.Text);
            }
            Scheduler schedule = new Scheduler(DateTime.Today);
            bool result = schedule.CheckBooking(Calender.SelectedDate, Descriptions);
            TextBox1.Text = result.ToString();
        }
    }
}