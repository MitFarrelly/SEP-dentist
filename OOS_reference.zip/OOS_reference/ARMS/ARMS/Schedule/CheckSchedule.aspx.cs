﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ControllerClass;

namespace KangrooUniversity.Schedule
{
    public partial class CheckSchedule : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (StaffList.Items.Count <= 0)
            {
                Scheduler controller = new Scheduler(DateTime.Today);
                List<String> descriptions = controller.getStaffNames();
                StaffList.Items.Add("------");
                foreach (String index in descriptions)
                {
                    StaffList.Items.Add(index);
                }
                Date.SelectedDate = DateTime.Today;
            }
        }

        protected void Check_Click(object sender, EventArgs e)
        {
            if (StaffList.SelectedIndex != 0)
            {
                Scheduler controller = new Scheduler(DateTime.Today);
                List<String> results;
                results = controller.lookUpScheduleFromName(StaffList.SelectedItem.Text, Date.SelectedDate);
                if (results.Count <= 0)
                    Results.Text = "Nothing";
                else
                {
                    Results.Text = "";
                    foreach (String entry in results)
                    {
                        Results.Text += entry;
                        Results.Text += "\n";
                    } 
                }
            }
        }
    }
}