﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;

namespace PersistantLayer
{
    public class DataBaseHandler
    {
        public enum Status
        {
            correct,
            invalidInput,
            failed,
        }

        static void Main(string[] args)
        {

        }

        OleDbConnection oleConn;
        string connString = @"Provider=Microsoft.ACE.OLEDB.12.0; Data source=F:\Group Implement\DataBase.accdb";
        public DataBaseHandler()
        {
            oleConn = new OleDbConnection(connString);
        }

        public List<String> getSchedule(DateTime date)
        {
            //SQL command to insert a new passenger

            string Date = date.Month.ToString() + "/" + date.Day.ToString() + "/" + date.Year.ToString();

            string sql = "Select JobID FROM Job WHERE (((JobDate)=#" + Date + "#))";

            oleConn.Open();
            List<String> Schedule = new List<string>();
            try
            {
                OleDbCommand command = new OleDbCommand(sql, oleConn);
                OleDbDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Schedule.Add(reader["JobID"].ToString());
                }
            }
            catch
            {
                throw new Exception();
            }
            finally
            {
                // Close the connection
                if (oleConn != null)
                {
                    oleConn.Close();
                }
            }
            return Schedule;
        }
        public DataTable GetALLCustomers()
        {
            try
            {
                oleConn.Open();

                string sql = "SELECT *, FirstName +' '+ LastName AS FullName FROM Customer";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sql, oleConn);
                DataTable dtBookings = new DataTable();
                dataAdapter.Fill(dtBookings);
                return dtBookings;

            }
            catch (Exception ex)
            {
                oleConn.Close();
                return null;
            }
            finally
            {
                oleConn.Close();
            }

        }
        public Status getJob(String JobID, out string BookingID, out int WorktypeID, out string StaffID, out bool Assigned, out DateTime JobDate)
        {
            Status stat = Status.failed;
            BookingID =  StaffID = null;
            WorktypeID = 0;
            Assigned = false;
            JobDate = new DateTime();
            oleConn.Open();
            try
            {
                stat = Status.invalidInput;
                //Finding the class of travel for the passenger
                string sqlQuery = "SELECT * FROM Job WHERE JobID =" + JobID;
                OleDbCommand command = new OleDbCommand(sqlQuery, oleConn);
                OleDbDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {

                    BookingID = reader["BookingID"].ToString();
                    WorktypeID = int.Parse(reader["WorkTypeID"].ToString());
                    StaffID = reader["StaffID"].ToString();
                    Assigned = (bool)reader["Assigned"];
                    JobDate = (DateTime)reader["JobDate"];
                    if (BookingID != null)
                        stat = Status.correct;
                }
                else
                    stat = Status.failed;
            }
            catch
            {
                throw new Exception();
            }
            finally
            {
                // Close the connection
                if (oleConn != null)
                {
                    oleConn.Close();
                }
            }
            return stat;
        }


        public DataTable getAllUnalocatedJob()
        {
            oleConn.Open();
            try
            {
                string sqlQuery = "SELECT * FROM Job WHERE Assigned = false";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlQuery, oleConn);
                DataTable dtJobs = new DataTable();
                dataAdapter.Fill(dtJobs);
                oleConn.Close();
                return dtJobs;
            }
            catch
            {
                throw new Exception();
            }
            finally
            {
                // Close the connection
                if (oleConn != null)
                {
                    oleConn.Close();
                }
            }
        }

        public void getWorkType(int WorktypeID, out int hoursNeeded)
        {
            hoursNeeded = 0;
            oleConn.Open();
            try
            {
                //Finding the class of travel for the passenger
                string sqlQuery = "Select * FROM WorkType WHERE WorkTypeID =" + WorktypeID.ToString();
                OleDbCommand command = new OleDbCommand(sqlQuery, oleConn);
                OleDbDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    hoursNeeded = Math.Abs(Convert.ToInt32(reader["EstimatedTime"].ToString()));
                }
            }
            catch
            {
                throw new Exception();
            }
            finally
            {
                // Close the connection
                if (oleConn != null)
                {
                    oleConn.Close();
                }
            }
        }

        public Status getStaff(String StaffID)
        {
            Status stat = Status.failed;
            string firstName = null;
            oleConn.Open();
            try
            {
                stat = Status.invalidInput;
                //Finding the class of travel for the passenger
                //string sqlQuery = "SELECT * FROM Job WHERE JobID =" + JobID;
                string sqlQuery = "SELECT FirstName FROM Staff WHERE StaffID =" + StaffID;
                OleDbCommand command = new OleDbCommand(sqlQuery, oleConn);
                OleDbDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    stat = Status.correct;
                }                
            }
            catch
            {
                throw new Exception();
            }
            finally
            {
                // Close the connection
                if (oleConn != null)
                {
                    oleConn.Close();
                }
            }
            return stat;
        }

        public String getStaffName(String Name)
        {
            String ID = null;
            oleConn.Open();
            try
            {
                string sqlQuery = "SELECT StaffID FROM Staff WHERE FirstName =" + "'" + Name + "'";
                OleDbCommand command = new OleDbCommand(sqlQuery, oleConn);
                OleDbDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    ID = reader["StaffID"].ToString();
                }
            }
            catch
            {
                throw new Exception();
            }
            finally
            {
                // Close the connection
                if (oleConn != null)
                {
                    oleConn.Close();
                }
            }
            return ID;
        }

        public DataTable getAllStaff()
        {
            oleConn.Open();
            try
            {
                string sql = "SELECT * FROM Staff";

                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sql, oleConn);
                DataTable dtWorkType = new DataTable();
                dataAdapter.Fill(dtWorkType);
                oleConn.Close();
                return dtWorkType;
            }
            catch
            {
                throw new Exception();
            }
            finally
            {
                if (oleConn != null)
                {
                    oleConn.Close();
                }
            }
        }

        public void getWorkTypeByDescription(String Description, out int ID)
        {
            ID = -1;
            oleConn.Open();
            try
            {
                //Finding the class of travel for the passenger
                string sqlQuery = "Select * FROM WorkType WHERE Description =" + "'" + Description + "'";
                OleDbCommand command = new OleDbCommand(sqlQuery, oleConn);
                OleDbDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    ID = Math.Abs(Convert.ToInt32(reader["WorkTypeID"].ToString()));
                }
            }
            catch
            {
                throw new Exception();
            }
            finally
            {
                // Close the connection
                if (oleConn != null)
                {
                    oleConn.Close();
                }
            }
        }

        public void updateJob(int JobID , int StaffID, bool assigned)
        {

            oleConn.Open();
            try
            {
                string sqlStatement = "UPDATE Job SET StaffID=" + StaffID + ", Assigned =" + assigned + " WHERE JobID= " + JobID;
                OleDbCommand command = new OleDbCommand(sqlStatement, oleConn);
                command.ExecuteNonQuery();
                oleConn.Close();
            }
            catch
            {
                throw new Exception();
            }
            finally
            {
                if (oleConn != null)
                {
                    oleConn.Close();
                }
            }

        }

        #region "Booking Management"
        public DataTable FetchBookings(int CustomerID)
        {
            try
            {
                oleConn.Open();

                string sql = "SELECT BookingID, CustomerID, ReminderID, RegNo, ServiceDate, ServiceTime, Status, Description ";
                sql += "FROM Booking ";
                //sql += "Where CustomerID = " + CustomerID.ToString() + "";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sql, oleConn);
                DataTable dtBookings = new DataTable();
                dataAdapter.Fill(dtBookings);
                return dtBookings;

            }
            catch (Exception ex)
            {
                oleConn.Close();
                return null;
            }
            finally
            {
                oleConn.Close();
            }

        }

        public DataSet FetchBookingDetails(int BookingNo)
        {
            try
            {
                oleConn.Open();

                string sql = "SELECT BookingID, CustomerID, ReminderID, RegNo, ServiceDate, ServiceTime, Status, Description ";
                sql += "FROM Booking ";
                sql += "Where BookingID = " + BookingNo.ToString() + "";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sql, oleConn);
                DataSet dtBookings = new DataSet();
                dataAdapter.Fill(dtBookings, "Booking");


                sql = "SELECT DetailID, BookingID, WorkType.WorkTypeID, WorkType.Description, WorkType.EstimatedTime, WorkType.EquipmentNeeded ";
                sql += "FROM BookingDetails INNER JOIN WorkType ON BookingDetails.WorkTypeID = WorkType.WorkTypeID ";
                sql += "Where BookingID =" + BookingNo.ToString() + "";
                dataAdapter.SelectCommand.CommandText = sql;
                dataAdapter.Fill(dtBookings, "BookingDetails");
                return dtBookings;

            }
            catch (Exception ex)
            {
                oleConn.Close();
                return null;
            }
            finally
            {
                oleConn.Close();
            }

        }

        public int DeleteBooking(int BookingNo)
        {
            try
            {
                oleConn.Open();

                string sql = "Delete From Booking Where BookingID=" + BookingNo.ToString() + "";
                OleDbCommand cmd = new OleDbCommand(sql, oleConn);
                int res = cmd.ExecuteNonQuery();

                sql = "Delete From BookingDetails Where BookingID =" + BookingNo.ToString() + "";
                cmd.CommandText = sql;
                cmd.ExecuteNonQuery();
                return res;
            }
            catch (Exception ex)
            {
                oleConn.Close();
                return 0;
            }
            finally
            {
                oleConn.Close();
            }
        }

        public int SaveBooking(DateTime date, string status, int customerID, string RegNo, string description, int[] worktypeID)
        {


            try
            {
                
                int BookingNo = 0;
                if ((worktypeID.Length > 0) && (worktypeID.Length <= 3))
                {
                    if (date.Date >= DateTime.Now.Date)
                    {


                        oleConn.Open();
                        string Status = "New";
                        status = Status;
                        string sql = "Insert into Booking (CustomerID, ReminderID, RegNo, ServiceDate, ServiceTime, Status, Description) VALUES ";
                        sql += "('" + customerID.ToString() + "', '" + 0.ToString() + "', '" + RegNo.ToString() + "', '" + date.ToShortDateString() + "', '" + date.ToShortTimeString() + "', '" + status.ToString() + "', '" + description + "') ";
                        OleDbCommand cmd = new OleDbCommand(sql, oleConn);
                        cmd.ExecuteNonQuery();

                        cmd.CommandText = "Select @@Identity";
                        BookingNo = (int)cmd.ExecuteScalar();


                        for (int i = 0; i < worktypeID.Length; i++)
                        {
                            //foreach (WorkType objWorkType in objBooking.ObjWorkTypes)
                            //{
                                sql = "Insert into BookingDetails (BookingID, WorkTypeID) VALUES ";
                                sql += "('" + BookingNo + "', '" + worktypeID[i].ToString() + "') ";
                                cmd.CommandText = sql;
                                cmd.ExecuteNonQuery();
                                sql = "";
                            //}
                        }
                    }
                }
                return BookingNo;


            }
            catch (Exception ex)
            {
                oleConn.Close();
                return 0;
            }
            finally
            {
                oleConn.Close();
            }
        }

        public DataTable GetAllWorkTypes()
        {
            try
            {
                oleConn.Open();

                string sql = "SELECT WorkTypeID, Description, EstimatedTime, EquipmentNeeded, NonMemberCost, MemberCost ";
                sql += "FROM WorkType Order By Description ASC";

                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sql, oleConn);
                DataTable dtWorkType = new DataTable();
                dataAdapter.Fill(dtWorkType);
                return dtWorkType;

            }
            catch (Exception ex)
            {
                oleConn.Close();
                return null;
            }
            finally
            {
                oleConn.Close();
            }

        }

        public DataTable GetWorkTypeByID(int WorkTypeID)
        {
            try
            {
                oleConn.Open();

                string sql = "SELECT * FROM WorkType Where WorkTypeID =" + WorkTypeID.ToString();

                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sql, oleConn);
                DataTable dtWorkType = new DataTable();
                dataAdapter.Fill(dtWorkType);
                return dtWorkType;

            }
            catch (Exception ex)
            {
                oleConn.Close();
                return null;
            }
            finally
            {
                oleConn.Close();
            }

        }

        #endregion

        public bool login(string Staff_ID, string password)
        {
            bool isVerified = false;

            //Validating user againt Database
            //Connect to Database
            OleDbConnection connection = new OleDbConnection(connString);
            connection.Open();

            try
            {
                //Checking whether the user supplied staffid exists 
                string sqlQuery = "SELECT StaffID, Password FROM Staff WHERE StaffID=" + Staff_ID + " AND Password='" + password + "'";
                OleDbCommand command = new OleDbCommand(sqlQuery, connection);
                OleDbDataReader reader = command.ExecuteReader();
                reader.Read();
                isVerified = reader.HasRows;
            }
            catch
            {
                throw new Exception();
            }
            finally
            {
                // Close the connection
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return isVerified;
        }


        public void createPayment(string Payment_ID, string Customer_ID, string CreditCard_NO, string NameOnCard, string ExpireDate, string Status)
        {
            //Connect to DB
            OleDbConnection con = new OleDbConnection(connString);
            con.Open();
            //SQL command to insert a new payment
            string sql = "INSERT INTO Payment (PaymentID, CustomerID, CreditCardNum, NameOnCard, ExpireDate, Status)  "
                         + "VALUES(" + Payment_ID + ",'" + Customer_ID + "','" + CreditCard_NO + "','" + NameOnCard + "','" + ExpireDate + "','" + Status + "' );";
            try
            {
                OleDbCommand command = new OleDbCommand(sql, con);
                command.ExecuteNonQuery();
                con.Close();
            }
            catch
            {
                throw new Exception();
            }
            finally
            {
                // Close the connection
                if (con != null)
                {
                    con.Close();
                }
            }
        }

        public void deletePayment(string Payment_ID)
        {
            //Connect to DB
            OleDbConnection con = new OleDbConnection(connString);
            con.Open();
            //SQL command to update the payment table
            string sql = "DELETE FROM Payment WHERE (PaymentID =" + Payment_ID + ")";
            try
            {
                OleDbCommand command = new OleDbCommand(sql, con);
                command.ExecuteNonQuery();
                con.Close();
            }
            catch
            {
                throw new Exception();
            }
            finally
            {
                // Close the connection
                if (con != null)
                {
                    con.Close();
                }
            }
        }

        //Search if the seat no is already allocate to a payment by searching it in the payment Table

        public string[] searchPayment(string Payment_ID)
        {
            //Connect to DB
            OleDbConnection con = new OleDbConnection(connString);
            con.Open();
            try
            {
                //SQL command to select all payment and add to an array
                string sql = "SELECT * FROM Payment WHERE PaymentID =" + Payment_ID + "";
                OleDbCommand command = new OleDbCommand(sql, con);
                OleDbDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    string[] dbResult = new String[7];


                    dbResult[0] = "Success";
                    dbResult[1] = reader[0].ToString();
                    dbResult[2] = reader[1].ToString();
                    dbResult[3] = reader[2].ToString();
                    dbResult[4] = reader[3].ToString();
                    dbResult[5] = reader[4].ToString();
                    dbResult[6] = reader[5].ToString();

                    con.Close();

                    return dbResult;

                }
                else return new String[7];
            }
            catch
            {

                throw new Exception();
            }
            finally
            {
                // Close the connection
                if (con != null)
                {
                    con.Close();
                }
            }
        }

        public string[] searchPaymentThruCustomer(string Customer_ID)
        {
            //Connect to DB
            OleDbConnection con = new OleDbConnection(connString);
            con.Open();
            try
            {
                //SQL command to select all payment and add to an array
                string sql = "SELECT * FROM Payment WHERE CustomerID =" + Customer_ID + "";
                OleDbCommand command = new OleDbCommand(sql, con);
                OleDbDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    string[] dbResult = new String[7];

                    dbResult[0] = "Success";
                    dbResult[1] = reader[0].ToString();
                    dbResult[2] = reader[1].ToString();
                    dbResult[3] = reader[2].ToString();
                    dbResult[4] = reader[3].ToString();
                    dbResult[5] = reader[4].ToString();
                    dbResult[6] = reader[5].ToString();

                    con.Close();
                    return dbResult;

                }
                else return new String[7];
            }
            catch
            {
                throw new Exception();
            }
            finally
            {
                // Close the connection
                if (con != null)
                {
                    con.Close();
                }
            }
        }

        public void createCustomer(string Customer_ID, string FirstName, string LastName, string Title, string ContactNum, string Email, string Street, string Suburb, string State, string PostCode, string PaymentMethod, string Member)
        {
            //Connect to DB
            OleDbConnection con = new OleDbConnection(connString);
            con.Open();
            //SQL command to insert a new customer
            string sql = "INSERT INTO [Customer] ([FirstName], [LastName], [Title], [ContactNum],  [Email], [Street], [Suburb], [State], [PostCode], [PaymentMethod], [Member])VALUES('" + FirstName + "','" + LastName + "','" + Title + "','" + ContactNum + "','" + Email + "','" + Street + "','" + Suburb + "','" + State + "' ,'" + PostCode + "','" + PaymentMethod + "'," + Member + ");";
            try
            {
                OleDbCommand command = new OleDbCommand(sql, con);
                command.ExecuteNonQuery();
                con.Close();
            }
            //catch
            //{
            //    throw new Exception();
            //}
            finally
            {
                // Close the connection
                if (con != null)
                {
                    con.Close();
                }
            }
        }



        public void updateCustomer(string Customer_ID, string FirstName, string LastName, string Title, string ContactNum, string Email, string Street, string Suburb, string State, string PostCode, string PaymentMethod, string Member)
        {
            //Connect to DB
            OleDbConnection con = new OleDbConnection(connString);
            con.Open();
            //SQL command to insert a new customer
            string sql = "UPDATE Customer SET FirstName ='" + FirstName + "',LastName= '" + LastName + "', Title='" + Title + "',ContactNum='" + ContactNum + "',Email='" + Email + "',Street='" + Street + "',Suburb='" + Suburb + "',CheckIn_Status='" + State + "',PostCode='" + PostCode + "',PaymentMethod='" + PaymentMethod + "',Member='" + Member + "' WHERE CustomerID=" + Customer_ID + "";


            try
            {
                OleDbCommand command = new OleDbCommand(sql, con);
                command.ExecuteNonQuery();
                con.Close();
            }
            catch
            {
                throw new Exception();
            }
            finally
            {
                // Close the connection
                if (con != null)
                {
                    con.Close();
                }
            }
        }




        public void deleteCustomer(string Customer_ID)
        {
            //Connect to DB
            OleDbConnection con = new OleDbConnection(connString);
            con.Open();
            //SQL command to update the customer table
            string sql = "DELETE FROM Customer WHERE (CustomerID =" + Customer_ID + ")";
            try
            {
                OleDbCommand command = new OleDbCommand(sql, con);
                command.ExecuteNonQuery();
                con.Close();
            }
            catch
            {
                throw new Exception();
            }
            finally
            {
                // Close the connection
                if (con != null)
                {
                    con.Close();
                }
            }
        }

        //Search if the seat no is already allocate to a passenger by searching it in the reservation Table







        public string[] searchrCustomer(string Customer_ID)
        {
            //Connect to DB
            OleDbConnection con = new OleDbConnection(connString);
            con.Open();
            try
            {
                //SQL command to select all customers and add to an array
                string sql = "SELECT * FROM Customer WHERE CustomerID =" + Customer_ID + "";
                OleDbCommand command = new OleDbCommand(sql, con);
                OleDbDataReader reader = command.ExecuteReader();

                if (reader.Read() == true)
                {
                    string[] dbResult = new String[13];

                    dbResult[0] = "Success";
                    dbResult[1] = reader[0].ToString();
                    dbResult[2] = reader[1].ToString();
                    dbResult[3] = reader[2].ToString();
                    dbResult[4] = reader[3].ToString();
                    dbResult[5] = reader[4].ToString();
                    dbResult[6] = reader[5].ToString();
                    dbResult[7] = reader[6].ToString();
                    dbResult[8] = reader[7].ToString();
                    dbResult[9] = reader[8].ToString();
                    dbResult[10] = reader[9].ToString();
                    dbResult[11] = reader[10].ToString();
                    dbResult[12] = reader[11].ToString();

                    con.Close();
                    return dbResult;

                }
                else return new String[13];
            }
            catch
            {
                throw new Exception();
            }
            finally
            {
                // Close the connection
                if (con != null)
                {
                    con.Close();
                }
            }
        }
    }
}
