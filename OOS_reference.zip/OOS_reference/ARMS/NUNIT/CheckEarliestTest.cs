﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using ControllerClass;
using BusinessLayer;

namespace NUNIT
{
    [TestFixture]public class CheckEarliestTest
    {
        Scheduler scheduler;

        [SetUp]
        public void Init()
        {
            scheduler = new Scheduler(new DateTime(2013, 4, 20));
        }

        [Test]
        public void FindEarliestBooking()
        {
            Booking book = new Booking();
            WorkType work, work2, work3;
            work = new WorkType();
            work2 = new WorkType();
            work3 = new WorkType();
            work.WorkTypeID = 3;
            work2.WorkTypeID = 0;
            work3.WorkTypeID = 0;
            List<WorkType> list;
            list = new List<WorkType>();
            list.Add(work);
            list.Add(work2);
            list.Add(work3);
            book.Create(12, "12345", list, "this is a test", new DateTime(2013, 4, 20));
            scheduler = new Scheduler(new DateTime(2013, 4, 20));
            DateTime JobStatus = scheduler.FindEarliestBooking(book);
            Assert.AreEqual(new DateTime(2013, 4, 20), JobStatus);
        }

        [Test]
        public void FindEarliestBookingNextDay()
        {
            Booking book = new Booking();
            WorkType work, work2, work3;
            work = new WorkType();
            work2 = new WorkType();
            work3 = new WorkType();
            work.WorkTypeID = 3;
            work2.WorkTypeID = 0;
            work3.WorkTypeID = 0;
            List<WorkType> list;
            list = new List<WorkType>();
            list.Add(work);
            list.Add(work2);
            list.Add(work3);
            book.Create(12, "12345", list, "this is a test", new DateTime(2013, 4, 24));
            scheduler = new Scheduler(new DateTime(2013, 4, 23));
            DateTime JobStatus = scheduler.FindEarliestBooking(book);
            Assert.AreEqual(new DateTime(2013, 4, 24), JobStatus);
        }

        [Test]
        public void FindEarliestBooking2()
        {
            Booking book = new Booking();
            WorkType work, work2, work3;
            work = new WorkType();
            work2 = new WorkType();
            work3 = new WorkType();
            work.WorkTypeID = 3;
            work2.WorkTypeID = 0;
            work3.WorkTypeID = 0;
            List<WorkType> list;
            list = new List<WorkType>();
            list.Add(work);
            list.Add(work2);
            list.Add(work3);
            book.Create(12, "12345", list, "this is a test", new DateTime(2013, 4, 24));
            scheduler = new Scheduler(new DateTime(2013, 4, 24));
            DateTime JobStatus = scheduler.FindEarliestBooking(book);
            Assert.AreEqual(new DateTime(2013, 4, 24), JobStatus);
        }


        [Test]
        public void CheckBookingWork()
        {
            Booking book = new Booking();
            WorkType work, work2, work3;
            work = new WorkType();
            work2 = new WorkType();
            work3 = new WorkType();
            work.WorkTypeID = 3;
            work2.WorkTypeID = 0;
            work3.WorkTypeID = 0;
            List<WorkType> list;
            list = new List<WorkType>();
            list.Add(work);
            list.Add(work2);
            list.Add(work3);
            book.Create(12, "12345", list, "this is a test", new DateTime(2013, 4, 23));
            int JobStatus = book.GetTimeNeeded();
            Assert.AreEqual(1, JobStatus);
        }

        [Test]
        public void InvalidDate()
        {
            Booking book = new Booking();
            WorkType work, work2, work3;
            work = new WorkType();
            work2 = new WorkType();
            work3 = new WorkType();
            work.WorkTypeID = 3;
            work2.WorkTypeID = 0;
            work3.WorkTypeID = 0;
            List<WorkType> list;
            list = new List<WorkType>();
            list.Add(work);
            list.Add(work2);
            list.Add(work3);
            book.Create(12, "12345", list, "this is a test", new DateTime(1, 1, 1));
            scheduler = new Scheduler(new DateTime(2013, 4, 20));
            DateTime JobStatus = scheduler.FindEarliestBooking(book);
            Assert.AreEqual(new DateTime(1, 1, 1), JobStatus);
        }

        [Test]
        public void InvalidBooking()
        {
            Booking book = new Booking();
            WorkType work, work2, work3;
            work = new WorkType();
            work2 = new WorkType();
            work3 = new WorkType();
            work.WorkTypeID = 0;
            work2.WorkTypeID = 0;
            work3.WorkTypeID = 0;
            List<WorkType> list;
            list = new List<WorkType>();
            list.Add(work);
            list.Add(work2);
            list.Add(work3);
            book.Create(12, "12345", list, "this is a test", new DateTime(2013, 4, 20));
            scheduler = new Scheduler(new DateTime(2013, 4, 20));
            DateTime JobStatus = scheduler.FindEarliestBooking(book);
            Assert.AreEqual(new DateTime(1, 1, 1), JobStatus);
        }

        [Test]
        public void InvalidWork()
        {
            Booking book = new Booking();
            WorkType work, work2, work3;
            work = new WorkType();
            work2 = new WorkType();
            work3 = new WorkType();
            work.WorkTypeID = 2;
            work2.WorkTypeID = 1;
            work3.WorkTypeID = 3;
            List<WorkType> list;
            list = new List<WorkType>();
            list.Add(work);
            list.Add(work2);
            list.Add(work3);
            book.Create(12, "12345", list, "this is a test", new DateTime(2013, 4, 20));
            scheduler = new Scheduler(new DateTime(2013, 4, 20));
            DateTime JobStatus = scheduler.FindEarliestBooking(book);
            Assert.AreEqual(new DateTime(1, 1, 1), JobStatus);
        }
    }
}
