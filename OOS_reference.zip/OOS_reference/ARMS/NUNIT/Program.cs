﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ControllerClass;

namespace NUNIT
{
    class Program
    {
        static void Main(string[] args)
        {
            
            /*BookingController controller = new BookingController();
            
            List<BusinessLayer.WorkType> objWorkTypes = new List<BusinessLayer.WorkType>();
            BusinessLayer.WorkType objWorkType1 = new BusinessLayer.WorkType();
            objWorkType1.WorkTypeID=1;

            BusinessLayer.WorkType objWorkType2 = new BusinessLayer.WorkType();
            objWorkType2.WorkTypeID=2;

            BusinessLayer.WorkType objWorkType3 = new BusinessLayer.WorkType();
            objWorkType3.WorkTypeID=3;

            objWorkTypes.Add(objWorkType1);
            objWorkTypes.Add(objWorkType2);
            objWorkTypes.Add(objWorkType3);

            
            controller.SetCurrentBooking(controller.RequestBooking(1, "123", objWorkTypes, DateTime.Now, "test"));
            controller.ConfirmBooking();
            */

            /*BookingController controller = new BookingController();
            controller.CancelBooking(2);*/

            BookingController controller = new BookingController();
            controller.SearchBooking(7);





        }
    }
}
