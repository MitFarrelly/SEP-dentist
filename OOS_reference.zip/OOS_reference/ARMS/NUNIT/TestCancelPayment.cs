﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using BusinessLayer;
namespace Nunit
{
   
        [TestFixture]
        class TestCancelPayment
        {


            CancelPayment c;
            [SetUp]
            public void init()
            {
                c = new CancelPayment();
            }


            [Test]
            public void correctCancel()
            {

                string isCancel = "";
                isCancel = c.CancelPay("10");
                Assert.AreEqual("Success", isCancel, "Cancel successful");
            }
           [Test, ExpectedException(typeof(Exception))]
            public void nullCancel()
            {

                string isCancel = "";
                isCancel = c.CancelPay("");
            }
            [Test]
            public void invalidCancel()
            {

                string isCancel = "";
                isCancel = c.CancelPay("1000");
                Assert.AreEqual("Failure", isCancel, "Cancel Failure");
            }
        }
    
}
