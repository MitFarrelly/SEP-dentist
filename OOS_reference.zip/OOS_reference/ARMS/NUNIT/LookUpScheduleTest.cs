﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using ControllerClass;
using BusinessLayer;

namespace NUNIT
{
    [TestFixture]public class LookUpScheduleTest
    {
        Scheduler scheduler;

        [SetUp]
        public void Init()
        {
            scheduler = new Scheduler(new DateTime(2012, 4, 22));
        }

        [Test]
        public void LookupSchedule()
        {
            List<string> jobs = scheduler.lookUpSchedule("1", new DateTime(2013, 4, 23));
            string[] ids = new string[] { "0", "0", "0"};
            int i = 0;
            foreach (string job in jobs)
            {
                ids[i] = job;
                i++;
            }
            Assert.AreEqual(new string[] { "1", "0", "0" }, ids);
        }

        [Test]
        public void InvalidStaff()
        {
            List<string> jobs = scheduler.lookUpSchedule("-1", new DateTime(2013, 4, 24));
            string[] ids = new string[] { "0", "0", "0" };
            int i = 0;
            foreach (string job in jobs)
            {
                ids[i] = job;
                i++;
            }
            Assert.AreEqual(new string[] { "0", "0", "0" }, ids);
        }

        [Test]
        public void InvalidDate()
        {
            List<string> jobs = scheduler.lookUpSchedule("1", new DateTime(1, 1, 1));
            string[] ids = new string[] { "0", "0", "0" };
            int i = 0;
            foreach (string job in jobs)
            {
                ids[i] = job;
                i++;
            }
            Assert.AreEqual(new string[] { "0", "0", "0" }, ids);
        }

        [Test]
        public void MultipleJobs()
        {
            List<string> jobs = scheduler.lookUpSchedule("2", new DateTime(2013, 4, 24));
            string[] ids = new string[] { "0", "0", "0" };
            int i = 0;
            foreach (string job in jobs)
            {
                ids[i] = job;
                i++;
            }
            Assert.AreEqual(new string[] {"4", "5", "0"}, ids);
        }

        [Test]
        public void NoJobs()
        {
            List<string> jobs = scheduler.lookUpSchedule("2", new DateTime(2013, 4, 23));
            string[] ids = new string[] { "0", "0", "0" };
            int i = 0;
            foreach (string job in jobs)
            {
                ids[i] = job;
                i++;
            }
            Assert.AreEqual(new string[] { "0", "0", "0" }, ids);
        }
    }
}
