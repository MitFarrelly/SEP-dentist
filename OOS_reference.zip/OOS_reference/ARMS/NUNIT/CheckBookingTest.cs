﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using ControllerClass;
using BusinessLayer;

namespace NUNIT
{
    [TestFixture]public class CheckBookingTest
    {
        Scheduler scheduler;

        [SetUp]
        public void Init()
        {
            scheduler = new Scheduler(new DateTime(2013, 4, 22));
        }

        [Test]
        public void CheckJobWork()
        {
            int JobStatus = new Job("12", "2", 4, "2", true, new DateTime(2013, 4, 22)).getNeededTime();
            Assert.AreEqual(1, JobStatus);
        }

        [Test]
        public void CheckBookingEmptyDay()
        {
            Booking book = new Booking();
            WorkType work, work2, work3;
            work = new WorkType();
            work2 = new WorkType();
            work3 = new WorkType();
            work.WorkTypeID = 3;
            work2.WorkTypeID = 0;
            work3.WorkTypeID = 0;
            List<WorkType> list;
            list = new List<WorkType>();
            list.Add(work);
            list.Add(work2);
            list.Add(work3);
            book.Create(12, "12345", list, "this is a test", new DateTime(2013, 4, 22));
            bool JobStatus = scheduler.CheckBooking(new DateTime(2013, 4, 22), book);
            Assert.AreEqual(true, JobStatus);
        }

        [Test]
        public void CheckBookingPartialDay()
        {
            Booking book = new Booking();
            WorkType work, work2, work3;
            work = new WorkType();
            work2 = new WorkType();
            work3 = new WorkType();
            work.WorkTypeID = 3;
            work2.WorkTypeID = 0;
            work3.WorkTypeID = 0;
            List<WorkType> list;
            list = new List<WorkType>();
            list.Add(work);
            list.Add(work2);
            list.Add(work3);
            book.Create(12, "12345", list, "this is a test", new DateTime(2013, 4, 24));
            bool JobStatus = scheduler.CheckBooking(new DateTime(2013, 4, 24), book);
            Assert.AreEqual(true, JobStatus);
        }

        [Test]
        public void FailBookingFullDay()
        {
            Booking book = new Booking();
            WorkType work, work2, work3;
            work = new WorkType();
            work2 = new WorkType();
            work3 = new WorkType();
            work.WorkTypeID = 3;
            work2.WorkTypeID = 0;
            work3.WorkTypeID = 0;
            List<WorkType> list;
            list = new List<WorkType>();
            list.Add(work);
            list.Add(work2);
            list.Add(work3);
            book.Create(12, "12345", list, "this is a test", new DateTime(2013, 4, 23));
            bool JobStatus = scheduler.CheckBooking(new DateTime(2013, 4, 23), book);
            Assert.AreEqual(false, JobStatus);
        }

        [Test]
        public void InvalidDate()
        {
            Booking book = new Booking();
            WorkType work, work2, work3;
            work = new WorkType();
            work2 = new WorkType();
            work3 = new WorkType();
            work.WorkTypeID = 3;
            work2.WorkTypeID = 0;
            work3.WorkTypeID = 0;
            List<WorkType> list;
            list = new List<WorkType>();
            list.Add(work);
            list.Add(work2);
            list.Add(work3);
            book.Create(12, "12345", list, "this is a test", new DateTime(2, 4, 22));
            bool JobStatus = scheduler.CheckBooking(new DateTime(2, 4, 22), book);
            Assert.AreEqual(false, JobStatus);
        }

        [Test]
        public void InvalidDateBooking()
        {
            Booking book = new Booking();
            WorkType work, work2, work3;
            work = new WorkType();
            work2 = new WorkType();
            work3 = new WorkType();
            work.WorkTypeID = 3;
            work2.WorkTypeID = 0;
            work3.WorkTypeID = 0;
            List<WorkType> list;
            list = new List<WorkType>();
            list.Add(work);
            list.Add(work2);
            list.Add(work3);
            book.Create(12, "12345", list, "this is a test", new DateTime(2, 4, 22));
            bool JobStatus = scheduler.CheckBooking(new DateTime(2, 4, 22), book);
            Assert.AreEqual(false, JobStatus);
        }

        [Test]
        public void BigBooking()
        {
            Booking book = new Booking();
            WorkType work, work2, work3;
            work = new WorkType();
            work2 = new WorkType();
            work3 = new WorkType();
            work.WorkTypeID = 1;
            work2.WorkTypeID = 2;
            work3.WorkTypeID = 3;
            List<WorkType> list;
            list = new List<WorkType>();
            list.Add(work);
            list.Add(work2);
            list.Add(work3);
            book.Create(12, "12345", list, "this is a test", new DateTime(2013, 4, 22));
            bool JobStatus = scheduler.CheckBooking(new DateTime(2013, 4, 22), book);
            Assert.AreEqual(false, JobStatus);
        }
    }
}
