﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BusinessLayer;
using NUnit.Framework;

namespace Nunit
{
    [TestFixture]
    class TestSearchPaymentThruPaymentID
    {
        SearchPayment s;
        [SetUp]
        public void init()
        {
            s = new SearchPayment();
        }

        [Test]
        public void correctsearch()
        {
            string[] issearch = s.searchPayment("5");
            string[] result = new String[7];
            result[0] = "Success";
            result[1] = "5";
            result[2] = "44";
            result[3] = "234535";
            result[4] = "gsdgdg";
            result[5] = "12/04/2013 12:00:00 AM";
            result[6] = "wert";

            Assert.AreEqual(result, issearch, "searching successful");
        }
        [Test]
        public void wrongsearch()
        {
            string[] issearch = s.searchPayment("2163");
            string[] result = new String[7];
          
            
            
            
            Assert.AreEqual(result, issearch, "searching successful");
        }
        [Test, ExpectedException(typeof(Exception))]
        public void invalidLogin()
        {
            string[] issearch = s.searchPayment("");
        }

        
    }
}