﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using ControllerClass;

namespace NUNIT
{
    [TestFixture]public class AssignJobTest
    {
        Scheduler scheduler;

        [SetUp]
        public void Init()
        {
            scheduler = new Scheduler(new DateTime(2012, 4, 22));
        }

        [Test]
        public void Assignjob()
        {
            bool JobStatus = scheduler.allocateJob("1", "1");
            Assert.AreEqual(true, JobStatus);
        }

        [Test]
        public void Assignjob2()
        {
            bool JobStatus = scheduler.allocateJob("3", "2");
            Assert.AreEqual(true, JobStatus);
        }

        [Test]
        public void InvalidID()
        {
            bool JobStatus = scheduler.allocateJob("0", "23");
            Assert.AreEqual(false, JobStatus);
        }

        [Test]
        public void NegativeID()
        {
            bool JobStatus = scheduler.allocateJob("-3", "-54");
            Assert.AreEqual(false, JobStatus);
        }

        [Test]
        public void JobAllreadyAssigned()
        {
            bool JobStatus = scheduler.allocateJob("1", "1");
            Assert.AreEqual(true, JobStatus);
        }

        [Test]
        public void InvaidStaffID()
        {
            bool JobStatus = scheduler.allocateJob("1", "-1");
            Assert.AreEqual(false, JobStatus);
        }
    }
}
