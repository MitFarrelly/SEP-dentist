﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using BusinessLayer;
using ControllerClass;

namespace NUNIT
{
    [TestFixture] class CreateBookingTest
    {
        [Test]
        public void NewBookingWithOneWorkType() {
            BookingController controller = new BookingController();
            List<BusinessLayer.WorkType> objWorkTypes = new List<BusinessLayer.WorkType>();
            BusinessLayer.WorkType objWorkType1 = new BusinessLayer.WorkType();
            objWorkType1.WorkTypeID = 1;
            objWorkTypes.Add(objWorkType1);
            controller.SetCurrentBooking(controller.RequestBooking(1, "RG 123", objWorkTypes, DateTime.Now, "test"));
            int BookingNo = controller.ConfirmBooking();
            Assert.Greater(BookingNo,0, "Booking Created Successfully");
        }

        [Test]
        public void NewBookingWithMultipleWorkTypes()
        {
            BookingController controller = new BookingController();
            List<BusinessLayer.WorkType> objWorkTypes = new List<BusinessLayer.WorkType>();
            BusinessLayer.WorkType objWorkType1 = new BusinessLayer.WorkType();
            objWorkType1.WorkTypeID = 1;
            BusinessLayer.WorkType objWorkType2 = new BusinessLayer.WorkType();
            objWorkType2.WorkTypeID = 2;
            BusinessLayer.WorkType objWorkType3 = new BusinessLayer.WorkType();
            objWorkType3.WorkTypeID = 3;
            objWorkTypes.Add(objWorkType1);
            objWorkTypes.Add(objWorkType2);
            objWorkTypes.Add(objWorkType3);
            controller.SetCurrentBooking(controller.RequestBooking(1, "RG 123", objWorkTypes, DateTime.Now, "Car Service and Break change required"));
            int BookingNo = controller.ConfirmBooking();

            Assert.Greater(BookingNo, 0, "Booking Created Successfully");
        }

        [Test]
        public void NewBookingWithoutSpecifyingTypeOfWork()
        {
            BookingController controller = new BookingController();
            List<BusinessLayer.WorkType> objWorkTypes = new List<BusinessLayer.WorkType>();
            controller.SetCurrentBooking(controller.RequestBooking(1, "RG 123", null, DateTime.Now, "test"));
            int BookingNo = controller.ConfirmBooking();
            Assert.AreEqual(0, BookingNo, "Booking Cannot be created without Specifying the type of work required");
        }

        [Test]
        public void NewBookingWithoutBookingDetails()
        {
            BookingController controller = new BookingController();
            List<BusinessLayer.WorkType> objWorkTypes = new List<BusinessLayer.WorkType>();
            controller.SetCurrentBooking(controller.RequestBooking(1, string.Empty, null, DateTime.MinValue, string.Empty));
            int BookingNo = controller.ConfirmBooking();
            Assert.AreEqual(0, BookingNo, "Booking Cannot be created without Specifying details");
        }

        [Test]
        public void NewBookingWithoutBookingDetails_2()
        {
            BookingController controller = new BookingController();
            List<BusinessLayer.WorkType> objWorkTypes = new List<BusinessLayer.WorkType>();
            controller.SetCurrentBooking(controller.RequestBooking(1, string.Empty, null, DateTime.MinValue, string.Empty));
            int BookingNo = controller.ConfirmBooking();
            Assert.AreEqual(BookingNo, 0, "Booking Cannot be created without Specifying details");
        }

        [Test]
        public void NewBookingWithPastDate()
        {
            BookingController controller = new BookingController();
            List<BusinessLayer.WorkType> objWorkTypes = new List<BusinessLayer.WorkType>();
            BusinessLayer.WorkType objWorkType1 = new BusinessLayer.WorkType();
            objWorkType1.WorkTypeID = 1;
            BusinessLayer.WorkType objWorkType2 = new BusinessLayer.WorkType();
            objWorkType2.WorkTypeID = 2;
            BusinessLayer.WorkType objWorkType3 = new BusinessLayer.WorkType();
            objWorkType3.WorkTypeID = 3;
            objWorkTypes.Add(objWorkType1);
            objWorkTypes.Add(objWorkType2);
            objWorkTypes.Add(objWorkType3);
            controller.SetCurrentBooking(controller.RequestBooking(1, "RG 123", objWorkTypes, DateTime.Now.AddDays(-5), "Car Service and Break change required"));
            int BookingNo = controller.ConfirmBooking();

            Assert.AreEqual(0, BookingNo, "Booking Cannot be created in Past");
        }

        [Test]
        public void NewBookingWithFutureDate()
        {
            BookingController controller = new BookingController();
            List<BusinessLayer.WorkType> objWorkTypes = new List<BusinessLayer.WorkType>();
            BusinessLayer.WorkType objWorkType1 = new BusinessLayer.WorkType();
            objWorkType1.WorkTypeID = 1;
            BusinessLayer.WorkType objWorkType2 = new BusinessLayer.WorkType();
            objWorkType2.WorkTypeID = 2;
            BusinessLayer.WorkType objWorkType3 = new BusinessLayer.WorkType();
            objWorkType3.WorkTypeID = 3;
            objWorkTypes.Add(objWorkType1);
            objWorkTypes.Add(objWorkType2);
            objWorkTypes.Add(objWorkType3);
            controller.SetCurrentBooking(controller.RequestBooking(1, "RG 123", objWorkTypes, DateTime.Now.AddDays(15), "Car Service and Break change required"));
            int BookingNo = controller.ConfirmBooking();

            Assert.Greater(BookingNo, 0, "Booking Cannot be created in Future");
        }

        [Test]
        public void NewBookingWithMoreThan3WorkTypes()
        {
            BookingController controller = new BookingController();
            List<BusinessLayer.WorkType> objWorkTypes = new List<BusinessLayer.WorkType>();
            
            BusinessLayer.WorkType objWorkType1 = new BusinessLayer.WorkType();
            objWorkType1.WorkTypeID = 1;
            
            BusinessLayer.WorkType objWorkType2 = new BusinessLayer.WorkType();
            objWorkType2.WorkTypeID = 2;
            
            BusinessLayer.WorkType objWorkType3 = new BusinessLayer.WorkType();
            objWorkType3.WorkTypeID = 3;
            
            BusinessLayer.WorkType objWorkType4 = new BusinessLayer.WorkType();
            objWorkType4.WorkTypeID = 4;
            
            BusinessLayer.WorkType objWorkType5 = new BusinessLayer.WorkType();
            objWorkType5.WorkTypeID = 5;

            objWorkTypes.Add(objWorkType1);
            objWorkTypes.Add(objWorkType2);
            objWorkTypes.Add(objWorkType3);
            objWorkTypes.Add(objWorkType4);
            objWorkTypes.Add(objWorkType5);
            
            controller.SetCurrentBooking(controller.RequestBooking(1, "RG 123", objWorkTypes, DateTime.Now.AddDays(15), "Car Service and Break change required"));
            int BookingNo = controller.ConfirmBooking();

            Assert.AreEqual(0, BookingNo, "Booking Cannot be created having more than 3 work types");
        }


    }
}

