﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using BusinessLayer;
using ControllerClass;

namespace NUNIT
{
    [TestFixture]
    class DeleteBookingTest
    {
        [Test]
        public void DeleteBooking()
        {
            BookingController controller = new BookingController();
            int result = controller.CancelBooking(60);
            Assert.Greater(result, 0, "BookingNo does not Exists");
        }
        [Test]
        public void DeleteBooking_2()
        {
            BookingController controller = new BookingController();
            int result = controller.CancelBooking(58);
            Assert.Greater(result, 0, "BookingNo does not Exists");
        }
        [Test]
        public void DeleteBooking_3()
        {
            BookingController controller = new BookingController();
            int result = controller.CancelBooking(16666);
            Assert.AreEqual(result, 0, "BookingNo does not Exists");
        }
        [Test]
        public void DeleteBooking_4()
        {
            BookingController controller = new BookingController();
            int result = controller.CancelBooking(90000);
            Assert.AreEqual(result, 0, "BookingNo does not Exists");
        }
        [Test, ExpectedException(typeof(FormatException))]
        public void DeleteBooking_5()
        {
            BookingController controller = new BookingController();
            int result = controller.CancelBooking(int.Parse("200.51"));
            Assert.AreEqual(result, 0, "BookingNo does not Exists");
        }
        [Test, ExpectedException(typeof(FormatException))]
        public void DeleteBooking_6()
        {
            BookingController controller = new BookingController();
            int result = controller.CancelBooking(int.Parse("Nothing"));
            Assert.AreEqual(result, 0, "BookingNo does not Exists");
        }
    }
}


