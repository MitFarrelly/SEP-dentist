﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using BusinessLayer;

namespace Nunit
{
    /*[TestFixture]
    public class TestLogin
    {
        login l;
        [SetUp]
        public void init()
        {
            l = new login();
        }

    [Test]
        public void correctLogin()
        {
           
            bool isLogin = false;
            isLogin = l.login("1", "123456789");
        Assert.AreEqual(true, isLogin, "Login successful");
        }
    [Test, ExpectedException(typeof(Exception))]
    public void invalidLogin()
    {

        l.login("", "");
            
    }
    [Test, ExpectedException(typeof(Exception))]
    public void invalidLogin1()
    {

        l.login("", "123456789");
            
    }
    [Test]
    public void invalidLogin2()
    {

        bool isLogin = false;
        isLogin = l.login("1", "");
            
        Assert.AreEqual(false, isLogin, "Login failure");
    }
    }*/
}

