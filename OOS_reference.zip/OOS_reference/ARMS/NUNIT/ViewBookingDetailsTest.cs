﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using BusinessLayer;
using ControllerClass;

namespace NUNIT
{
    class ViewBookingDetailsTest
    {
        [Test]
        public void ViewBookingDetails_1()
        {
            BookingController controller = new BookingController();
            List<BusinessLayer.WorkType> objWorkTypes = new List<BusinessLayer.WorkType>();

            BusinessLayer.WorkType objWorkType1 = new BusinessLayer.WorkType();
            objWorkType1.WorkTypeID = 1;
            objWorkTypes.Add(objWorkType1);

            BusinessLayer.WorkType objWorkType2 = new BusinessLayer.WorkType();
            objWorkType2.WorkTypeID = 2;
            objWorkTypes.Add(objWorkType2);

            BusinessLayer.WorkType objWorkType3 = new BusinessLayer.WorkType();
            objWorkType3.WorkTypeID = 3;
            objWorkTypes.Add(objWorkType3);


            Booking objBooking1 = controller.RequestBooking(1, "RG 123", objWorkTypes, DateTime.Parse("9/05/2013 2:51:00 PM"), "Car Service and Break change required");
            objBooking1.BookingNo = 54;
            Booking objBooking2 = controller.SearchBooking(54);
            Assert.True(objBooking1.BookingNo == objBooking2.BookingNo);
            Assert.AreEqual(objBooking1.BookingNo, objBooking2.BookingNo, "Results from seraching not matched");
            Assert.AreEqual(objBooking1.Date, objBooking2.Date, "Results from seraching not matched");
            Assert.AreEqual(objBooking1.Description, objBooking2.Description, "Results from seraching not matched");
            Assert.True(objBooking1.ObjCustomer.CustomerID == objBooking2.ObjCustomer.CustomerID);
            Assert.AreEqual(objBooking1.RegNo, objBooking2.RegNo, "Results from seraching not matched");
            Assert.AreEqual(objBooking1.Status, objBooking2.Status, "Results from seraching not matched");

        }

        [Test]
        public void ViewBookingDetails_2()
        {
            BookingController controller = new BookingController();
            List<BusinessLayer.WorkType> objWorkTypes = new List<BusinessLayer.WorkType>();

            BusinessLayer.WorkType objWorkType1 = new BusinessLayer.WorkType();
            objWorkType1.WorkTypeID = 1;
            objWorkTypes.Add(objWorkType1);

            BusinessLayer.WorkType objWorkType2 = new BusinessLayer.WorkType();
            objWorkType2.WorkTypeID = 2;
            objWorkTypes.Add(objWorkType2);

            BusinessLayer.WorkType objWorkType3 = new BusinessLayer.WorkType();
            objWorkType3.WorkTypeID = 3;
            objWorkTypes.Add(objWorkType3);


            Booking objBooking1 = controller.RequestBooking(1, "RG 123", objWorkTypes, DateTime.Parse("9/05/2013 2:51:00 PM"), "Car Service and Break change required");
            objBooking1.BookingNo = 57;
            Booking objBooking2 = controller.SearchBooking(57);
            Assert.True(objBooking1.BookingNo == objBooking2.BookingNo);
            Assert.AreEqual(objBooking1.BookingNo, objBooking2.BookingNo, "Results from seraching not matched");
            Assert.AreEqual(objBooking1.Date, objBooking2.Date, "Results from seraching not matched");
            Assert.AreEqual(objBooking1.Description, objBooking2.Description, "Results from seraching not matched");
            Assert.True(objBooking1.ObjCustomer.CustomerID == objBooking2.ObjCustomer.CustomerID);
            Assert.AreEqual(objBooking1.RegNo, objBooking2.RegNo, "Results from seraching not matched");
            Assert.AreEqual(objBooking1.Status, objBooking2.Status, "Results from seraching not matched");


        }

        [Test]
        public void ViewBookingDetails_InCorrectNumber()
        {
            BookingController controller = new BookingController();
            List<BusinessLayer.WorkType> objWorkTypes = new List<BusinessLayer.WorkType>();

            BusinessLayer.WorkType objWorkType1 = new BusinessLayer.WorkType();
            objWorkType1.WorkTypeID = 1;
            objWorkTypes.Add(objWorkType1);

            BusinessLayer.WorkType objWorkType2 = new BusinessLayer.WorkType();
            objWorkType2.WorkTypeID = 2;
            objWorkTypes.Add(objWorkType2);

            BusinessLayer.WorkType objWorkType3 = new BusinessLayer.WorkType();
            objWorkType3.WorkTypeID = 3;
            objWorkTypes.Add(objWorkType3);


            Booking objBooking1 = controller.RequestBooking(1, "RG 854544", objWorkTypes, DateTime.Parse("9/05/2013 4:51:00 PM"), "Car only");
            objBooking1.BookingNo = 50000;
            Booking objBooking2 = controller.SearchBooking(54);
            Assert.False(objBooking1.BookingNo == objBooking2.BookingNo);
            Assert.AreNotEqual(objBooking1.BookingNo, objBooking2.BookingNo, "Results from seraching not matched");
            Assert.AreNotEqual(objBooking1.Date, objBooking2.Date, "Results from seraching not matched");
            Assert.AreNotEqual(objBooking1.Description, objBooking2.Description, "Results from seraching not matched");
            Assert.AreNotEqual(objBooking1.RegNo, objBooking2.RegNo, "Results from seraching not matched");

        }

        [Test]
        public void ViewBookingDetails_InCorrectNumber2()
        {
            BookingController controller = new BookingController();
            List<BusinessLayer.WorkType> objWorkTypes = new List<BusinessLayer.WorkType>();

            BusinessLayer.WorkType objWorkType1 = new BusinessLayer.WorkType();
            objWorkType1.WorkTypeID = 1;
            objWorkTypes.Add(objWorkType1);

            BusinessLayer.WorkType objWorkType2 = new BusinessLayer.WorkType();
            objWorkType2.WorkTypeID = 2;
            objWorkTypes.Add(objWorkType2);

            BusinessLayer.WorkType objWorkType3 = new BusinessLayer.WorkType();
            objWorkType3.WorkTypeID = 3;
            objWorkTypes.Add(objWorkType3);


            Booking objBooking1 = controller.RequestBooking(1, "RG 987", objWorkTypes, DateTime.Parse("9/05/2013 3:51:00 PM"), "Car Service only");
            objBooking1.BookingNo = 50000;
            Booking objBooking2 = controller.SearchBooking(59);
            Assert.False(objBooking1.BookingNo == objBooking2.BookingNo);
            Assert.AreNotEqual(objBooking1.BookingNo, objBooking2.BookingNo, "Results from seraching not matched");
            
            

        }


        [Test]
        public void ViewBookingDetails_5()
        {
            BookingController controller = new BookingController();
            List<BusinessLayer.WorkType> objWorkTypes = new List<BusinessLayer.WorkType>();

            BusinessLayer.WorkType objWorkType1 = new BusinessLayer.WorkType();
            objWorkType1.WorkTypeID = 1;
            objWorkTypes.Add(objWorkType1);

            BusinessLayer.WorkType objWorkType2 = new BusinessLayer.WorkType();
            objWorkType2.WorkTypeID = 2;
            objWorkTypes.Add(objWorkType2);

            BusinessLayer.WorkType objWorkType3 = new BusinessLayer.WorkType();
            objWorkType3.WorkTypeID = 3;
            objWorkTypes.Add(objWorkType3);


            Booking objBooking1 = controller.RequestBooking(1, "RG 123", objWorkTypes, DateTime.Parse("9/05/2013 2:51:00 PM"), "Chnaged Description");
            objBooking1.BookingNo = 54;
            Booking objBooking2 = controller.SearchBooking(54);
            Assert.True(objBooking1.BookingNo == objBooking2.BookingNo);
            Assert.AreEqual(objBooking1.BookingNo, objBooking2.BookingNo, "Results from seraching not matched");
            Assert.AreEqual(objBooking1.Date, objBooking2.Date, "Results from seraching not matched");
            Assert.AreNotEqual(objBooking1.Description, objBooking2.Description, "Results from seraching not matched");
            
            Assert.AreEqual(objBooking1.RegNo, objBooking2.RegNo, "Results from seraching not matched");
            


        }
    }
}
