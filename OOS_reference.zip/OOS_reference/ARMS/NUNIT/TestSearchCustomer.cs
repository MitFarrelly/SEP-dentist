﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using BusinessLayer;

namespace Nunit
{
    [TestFixture]
    class TestSearchCustomer
    {
        SearchCustomer s;
        [SetUp]
        public void init()
        {
            s = new SearchCustomer();
        }

        [Test]
        public void correctsearch()
        {
            string[] issearch = s.searchCustomer("10");
            string[] result = new String[13];
            result[0] = "Success";
            result[1] = "10";
            result[2] = "Eilene";
            result[3] = "Callaghan";
            result[4] = "Miss";
            result[5] = "5058199476";
            result[6] = "Leda@armyspy.com";
            result[7] = "4074 Bethann  Street";
            result[8] = "Garcia";
            result[9] = " ACT";
            result[10] = "5874";
            result[11] = "Cash";
            result[12] = "False";
            
            Assert.AreEqual(result, issearch, "searching successful");
        }
        [Test]
        public void wrongsearch()
        {
            string[] issearch = s.searchCustomer("2165416503");
            string[] result = new String[13];
         
            Assert.AreEqual(result, issearch, "searching Fail");
        }
        [Test, ExpectedException(typeof(Exception))]
        public void invalidLogin()
        {
            string[] issearch = s.searchCustomer("");
        }
    }
}
