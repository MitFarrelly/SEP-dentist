﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using BusinessLayer;


namespace Nunit
{
     [TestFixture]
    public class TestCreateCustomer
    {
         CreateCustomer c;
         [SetUp]
         public void init()
         {
             c = new CreateCustomer();
         }
         [Test]
         public void correctCancel()
         {

             string isCreate = "";
             isCreate = c.createNewCustomer("1", "yty", "rrr", "g", "2131321329132", "o@.com", "212", "221", "ap", "dp", "card", "true");
             Assert.AreEqual("Success", isCreate, "Create successful");
         }
         [Test, ExpectedException(typeof(Exception))]
         public void nullCreate()
         {

             string isCreate = "";
             isCreate = c.createNewCustomer("", "", "", "", "", "", "", "", "", "", "", "");
         }
            
        
    }


   
}
